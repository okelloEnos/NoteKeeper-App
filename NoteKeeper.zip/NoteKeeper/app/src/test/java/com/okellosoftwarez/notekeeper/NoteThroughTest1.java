package com.okellosoftwarez.notekeeper;

////import org.junit.Test;
//import android.support.test.rule.Acti;
//import androidx.test.rul
//import static android.support.test.espresso.Espress.onView;
//public class NoteThroughTest {

//import org.junit.Rule;
//
//@Rule
//    public ActivityTestRule<NavActivity> mActivityTestRule = new ActivityTestRule(NavActivity.class);


//}

import org.junit.Rule;

@Rule
      public ActivityTestRule<NavActivity> mActivityTestRule = new Acti